<?php $__env->startSection('content'); ?>

<div class="containar" style="margin: 50px;" >
    <h3>Edit Client Data</h3>
    <form action="<?php echo e(route('client.update',$client->id)); ?>" method="POST">
    <?php echo e(csrf_field()); ?>

    <?php echo method_field('PATCH'); ?>
    <div class="row">
    	<div class="col-md-12">
         <div class="form-group">
           <strong>Titel</strong>
           <input type="text" value="<?php echo e($client->titel); ?>" name="titel" class="form-control"  placeholder="edit Titel">
           <span class="text-danger"><?php echo e($errors->first('titel')); ?></span>
         </div>
        </div>

        <div class="col-md-12">
	        <div class="form-group">
	            <strong>Status</strong>
	            <input type="text" value="<?php echo e($client->status); ?>" name="status" class="form-control" placeholder="Eidt Status">
	            <span class="text-danger"><?php echo e($errors->first('status')); ?></span>
	        </div>
        </div>

	    <div class="col-md-12">
	        <div class="form-group">
	            <strong>Contact Phone</strong>
	            <input type="text" value="<?php echo e($client->contact_phone); ?>" name="contact_phone" class="form-control" placeholder="Enter Contact Phone">
	            <span class="text-danger"><?php echo e($errors->first('contact_phone')); ?></span>
	        </div>
	    </div>



		<div class="col-md-12">
		    <div class="form-group">
		        <strong>Start Contract Date</strong>
		        <input type="Date" value="<?php echo e($client->start_contract_date); ?>"  name="start_contract_date" class="form-control" placeholder="Enter Start Contract Date">
		        <span class="text-danger"><?php echo e($errors->first('start_contract_date')); ?></span>
		    </div>
		</div> 


	    <div class="col-md-12">
	        <div class="form-group">
	            <strong>End Contract Date</strong>
	            <input type="Date" value="<?php echo e($client->end_contract_date); ?>" name="end_contract_date" class="form-control" placeholder="Enter End Contract Date">
	            <span class="text-danger"><?php echo e($errors->first('end_contract_date')); ?></span>
	        </div>   
	    </div>    



	    <div class="col-md-12">
	        <div class="form-group">
	            <strong>Description</strong>
	            <textarea class="form-control" col="4" name="description" placeholder="Enter Description"><?php echo e($client->description); ?></textarea>
	            <span class="text-danger"><?php echo e($errors->first('description')); ?></span>
	        </div>
	    </div>
	    	
        </div>
      <a href="<?php echo e(route('client.show',$client->id)); ?>" style="margin-right:100px;" class="btn btn-primary"> Cancel edit</a></td>

      <button type="submit"  class="btn btn-success" aria-pressed="true">Submit edit</button>
    </div>
    </form>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/DS-task/resources/views/clients/edit.blade.php ENDPATH**/ ?>