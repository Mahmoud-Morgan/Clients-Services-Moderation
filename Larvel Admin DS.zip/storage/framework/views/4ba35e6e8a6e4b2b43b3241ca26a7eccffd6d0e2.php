<?php $__env->startSection('content'); ?>

<div class="containar" style="margin: 50px;" >
    <h3>Edit Service</h3>
    <form class="form-inline" action="<?php echo e(route('servicename.update',$service->id)); ?>" method="POST">
    <?php echo e(csrf_field()); ?>

    <?php echo method_field('PATCH'); ?>
        <div class="form-group mb-2">
        <input type="text"  style="width:300px;" value="<?php echo e($service->service_name); ?>" name="service_name" class="form-control"  placeholder="edit Service">
        <span class="text-danger"><?php echo e($errors->first('service_name')); ?></span>
            <button type="submit" class="btn btn-success" aria-pressed="true">Submit edit</button>
        </div>
    </form>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/DS-task/resources/views/services_provieding/edit.blade.php ENDPATH**/ ?>