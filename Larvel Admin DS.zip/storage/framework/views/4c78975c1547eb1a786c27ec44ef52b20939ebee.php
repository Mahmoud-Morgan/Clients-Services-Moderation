<?php $__env->startSection('content'); ?>


	<div class="containar" style="margin: 50px;" >
	<h1>Adding New Client Service</h1>
	<h3> <strong>Client Titel :</strong><?php echo e($client->titel); ?></h3>
    <form action="<?php echo e(route('clientservises.store')); ?>" method="POST">
    <?php echo e(csrf_field()); ?>

    
		<div class="form-group">
            <strong>Select Service</strong>
            <select class="form-control" name="service_name_id">
				<?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<option value="<?php echo e($service->id); ?>" ><?php echo e($service->service_name); ?></option>
			    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <span class="text-danger"><?php echo e($errors->first('servics')); ?></span>
        </div>
		
		<input type="hidden"  name="client_id" value="<?php echo e($client->id); ?>">

        <div class="form-group">
            <strong>Type</strong>
            <input type="text" class="form-control"  name="type" placeholder="Enter Type">
            <span class="text-danger"><?php echo e($errors->first('type')); ?></span>
        </div>

        <div class="form-group">
            <strong>Link</strong>
            <input type="text" class="form-control"  name="link" placeholder="Enter Link">
            <span class="text-danger"><?php echo e($errors->first('link')); ?></span>
        </div>

        <div class="form-group">
            <strong>Description</strong>
            <textarea class="form-control" col="4"  name="description" placeholder="Enter Description"></textarea>
            <span class="text-danger"><?php echo e($errors->first('description')); ?></span>
        </div>
         
      <button type="submit"  class="btn btn-success" aria-pressed="true">Add Service</button>
    </form>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/DS-task/resources/views/client_services/create.blade.php ENDPATH**/ ?>