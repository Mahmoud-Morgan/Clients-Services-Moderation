<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <title>Laravel</title>

        <link rel="stylesheet" href="<?php echo e(mix('css/app.css')); ?>">
        
    <body style="padding-bottom: 70px;">
        <div class="container-fluid"> 
          
            <nav class="navbar navbar-expand-lg navbar-light bg-light" >
                <a class="navbar-brand" href="<?php echo e(route('client.index')); ?>">Digital Media Footprint</a>
                <div class="navbar-nav" style="width:80%; align=right;">
                    <a class="nav-item nav-link" style="align=right;" href="<?php echo e(route('client.index')); ?>">Clients</a>
                    <a class="nav-item nav-link" href="<?php echo e(route('servicename.index')); ?>">Services Providing</a>
                </div>
            </nav>

            <?php echo $__env->yieldContent('content'); ?>

       
        </div>
        <script src="<?php echo e(mix('js/app.js')); ?>"></script>
    </body>
</html><?php /**PATH /opt/lampp/htdocs/DS-task/resources/views/layouts/master.blade.php ENDPATH**/ ?>