<?php $__env->startSection('content'); ?>

  <br><br><br>
  <h2>Clients</h2>
  <br>
  <div class="row">
    <div class="col-12">
          
      <table class="table table-bordered" >
       <thead>
          <tr>
             <th>Titel</th>
             <th>Status</th>                 
             <th colspan="3"><center>Actions</center></th>
          </tr>
       </thead>
       <tbody>
          <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
             <td><?php echo e($client->titel); ?></td>
             <td><?php echo e($client->status); ?></td>
             <td><center><a href="<?php echo e(route('client.show',$client->id)); ?>" class="btn btn-primary">Info Details</a></center></td>
             <td><center><a href="<?php echo e(route('clientservises.show',$client->id)); ?>" class="btn btn-primary">Services</a></center></td>
             <td><center>
             <form action="<?php echo e(route('client.destroy', $client->id)); ?>" method="post">
              <?php echo e(csrf_field()); ?>

              <?php echo method_field('DELETE'); ?>
              <button class="btn btn-danger" type="submit">Delete</button>
            </form></center>
            </td>
          </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
       </tbody>
      </table>
          <a href="<?php echo e(route('client.create')); ?>" class="btn btn-success mb-2">Add New Client</a> 
          
    </div> 
  </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/DS-task/resources/views/clients/list.blade.php ENDPATH**/ ?>