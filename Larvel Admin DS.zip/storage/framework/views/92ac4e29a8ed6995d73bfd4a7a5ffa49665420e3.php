<?php $__env->startSection('content'); ?>

  <br><br><br>
  <h3>Services Providing</h3>
   <div class="row">
        <div class="col-12">
          
          <table class="table table-bordered" >
           <thead>
              <tr>
                 <th>Services</th>
                 <th colspan="2"><center>Actions</center></th>
              </tr>
           </thead>
           <tbody>
              <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                 <td><?php echo e($service->service_name); ?></td>
                 <td><a href="<?php echo e(route('servicename.edit',$service->id)); ?>" class="btn btn-primary">Edit</a></td>
                 <td>
                 <form action="<?php echo e(route('servicename.destroy', $service->id)); ?>" method="post">
                  <?php echo e(csrf_field()); ?>

                  <?php echo method_field('DELETE'); ?>
                  <button class="btn btn-danger" type="submit">Delete</button>
                </form>
                </td>
              </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
           </tbody>
          </table>
          <a href="<?php echo e(route('servicename.create')); ?>" class="btn btn-success mb-2">Add New Service</a> 
          
       </div> 
   </div>
 <?php $__env->stopSection(); ?>  
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/DS-task/resources/views/services_provieding/list.blade.php ENDPATH**/ ?>