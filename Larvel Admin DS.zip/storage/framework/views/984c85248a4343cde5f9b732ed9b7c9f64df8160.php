<?php $__env->startSection('content'); ?>

<div class="containar" style="margin: 50px;" >
    <h3>Adding New Service</h3>
    <form class="form-inline" action="<?php echo e(route('servicename.store')); ?>" method="POST">
    <?php echo e(csrf_field()); ?>

        <div class="form-group mb-2">
            <input type="text"  style="width:300px;" name="service_name" class="form-control"  placeholder="New Service Name">
            <span class="text-danger"><?php echo e($errors->first('service_name')); ?></span>
            <button type="submit" class="btn btn-success" aria-pressed="true">Adding Service</button>
        </div>
    </form>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/DS-task/resources/views/services_provieding/create.blade.php ENDPATH**/ ?>