<?php $__env->startSection('content'); ?>

  <br><br><br>
  <div class="jumbotron">
    <h2>Client Information</h2>
    <br>
   <div class="row">

    <div class="col-md-12">
      <div class="form-group">
       <p><strong>Titel :</strong><?php echo e($client->titel); ?></p> 
      </div>
    </div>

    <div class="col-md-12">
      <div class="form-group">
       <p><strong>Status :</strong><?php echo e($client->status); ?></p> 
      </div>
    </div>

    <div class="col-md-12">
      <div class="form-group">
        <p><strong>Contact Phone :</strong><?php echo e($client->contact_phone); ?></p>
      </div>  
    </div>

    <div class="col-md-12">
      <div class="form-group">
        <p><strong>Start Contract Date :</strong><?php echo e($client->start_contract_date); ?></p>
      </div>
    </div> 

    <div class="col-md-12">
      <div class="form-group">
        <p><strong>End Contract Date :</strong><?php echo e($client->end_contract_date); ?></p>
      </div>   
    </div>    

    <div class="col-md-12">
      <div class="form-group">
        <p><strong>Description :</strong><?php echo e($client->description); ?></p> 
      </div>
    </div>

  </div>

      
    <table>  
      <tr>
         <td style="width:100px" ><a href="<?php echo e(route('clientservises.show',$client->id)); ?>" class="btn btn-primary"> Services</a></td>
         <td style="width:100px"><center><a href="<?php echo e(route('client.edit',$client->id)); ?>" class="btn btn-primary">Edit Info</a></center></td>
         <td style="width:100px"><center>
         <form action="<?php echo e(route('client.destroy', $client->id)); ?>" method="post">
          <?php echo e(csrf_field()); ?>

          <?php echo method_field('DELETE'); ?>
          <button class="btn btn-danger" type="submit">Delete</button>
        </form></center>
        </td>
      </tr>  
    </table>
    <br><br>
   <a href="<?php echo e(route('client.index')); ?>" class="btn btn-primary"> Back to Clients List</a></td>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/DS-task/resources/views/clients/details.blade.php ENDPATH**/ ?>