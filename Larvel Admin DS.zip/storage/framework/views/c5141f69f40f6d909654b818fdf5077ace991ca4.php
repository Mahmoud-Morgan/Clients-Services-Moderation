<?php $__env->startSection('content'); ?>

	<div class="containar" style="margin: 50px;" >
    <h3>Edit Client Service</h3>
    <h4><?php echo e($service_name->service_name); ?></h4>
    <form action="<?php echo e(route('clientservises2.update',[$client_service->client_id,$client_service->service_name_id])); ?>" method="POST">
    <?php echo e(csrf_field()); ?>

    <?php echo method_field('PATCH'); ?>
		<div class="form-group">
            <strong>Type</strong>
            <input type="text" class="form-control" value="<?php echo e($client_service->type); ?>" name="type" placeholder="Enter Type">
            <span class="text-danger"><?php echo e($errors->first('type')); ?></span>
        </div>


        <div class="form-group">
            <strong>Link</strong>
            <input type="text" class="form-control" value="<?php echo e($client_service->link); ?>" name="link" placeholder="Enter Link">
            <span class="text-danger"><?php echo e($errors->first('link')); ?></span>
        </div>

        <div class="form-group">
            <strong>Description</strong>
            <textarea class="form-control" col="4"  name="description" placeholder="Enter Description"><?php echo e($client_service->description); ?></textarea>
            <span class="text-danger"><?php echo e($errors->first('description')); ?></span>
        </div>
         <a href="<?php echo e(route('clientservises.show',$client_service->client_id)); ?>" style="margin-right:100px;" class="btn btn-primary"> Cancel edit</a></td>

      <button type="submit"  class="btn btn-success" aria-pressed="true">Submit edit</button>
    </form>
   </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/DS-task/resources/views/client_services/edit.blade.php ENDPATH**/ ?>