<?php $__env->startSection('content'); ?>
<br>
<h1>Client Services</h1>
<h3> <strong>Client Titel :</strong><?php echo e($client->titel); ?></h3>
<br>
<?php $__currentLoopData = $client_services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	 <div class="jumbotron">
    <h4><?php echo e($service->service_name); ?></h4>
    <br>
   <div class="row">

    <div class="col-md-12">
      <div class="form-group">
       <p><strong>Type :</strong><?php echo e($service->type); ?></p> 
      </div>
    </div>

    <div class="col-md-12">
      <div class="form-group">
       <p><strong>Link :</strong><?php echo e($service->link); ?></p> 
      </div>
    </div>
 

    <div class="col-md-12">
      <div class="form-group">
        <p><strong>Description :</strong><?php echo e($service->description); ?></p> 
      </div>
    </div>

    <table>  
      <tr>
         <td style="width:150px" ><a href="<?php echo e(route('clientservises2.edit',[$client->id,$service->id])); ?>" class="btn btn-primary"> Edit Service</a></td>
      
         <td style="width:100px"><center>
         <form action="<?php echo e(route('clientservises2.destroy',[$client->id,$service->id])); ?>" method="post">
          <?php echo e(csrf_field()); ?>

          <?php echo method_field('DELETE'); ?>
          <button class="btn btn-danger" type="submit">Delete</button>
        </form></center>
        </td>
      </tr>  
    </table>

  </div>
  </div>
<br>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<a  style="margin-right: 50px;" href="<?php echo e(route('client.show',$client->id)); ?>" class="btn btn-primary">Back to Client Info </a>
<a href="<?php echo e(route('clientservises2.create',$client->id)); ?>" class="btn btn-success">Add new Client Service </a>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/DS-task/resources/views/client_services/list.blade.php ENDPATH**/ ?>